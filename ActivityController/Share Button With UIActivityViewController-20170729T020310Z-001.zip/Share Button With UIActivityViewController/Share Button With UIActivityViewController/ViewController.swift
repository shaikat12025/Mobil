//
//  ViewController.swift
//  Share Button With UIActivityViewController
//
//  Created by Sium on 7/3/17.
//  Copyright © 2017 Sium. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgViewOutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func ShareBTN(_ sender: Any) {
        
        
        // here u have to declare what u want to share .. such as.. string , images .
//        let activityVC = UIActivityViewController(activityItems: ["www.google.com"], applicationActivities: nil)
        
        
        let activityVC = UIActivityViewController(activityItems: [self.imgViewOutlet.image!], applicationActivities: nil)
        
        // to pop over
        activityVC.popoverPresentationController?.sourceView = self.view
        
        self.present(activityVC, animated: true, completion: nil)
        
    }
}

